/* Version of sbrk for no operating system.  */

#include "config.h"
#include <_syslist.h>

#define PAGE_SIZE	4096
extern void * get_current_page_dir();
extern void * get_page();
extern void add_page_to_page_dir(void *, void *, void *);

void *
_sbrk (incr)
     int incr;
{ 
   extern char   end; /* Set by linker.  */
   static char * heap_end; 
   char *        prev_heap_end; 
   void *	pd;
   void *	page;


   if (heap_end == 0)
     heap_end = & end; 

   prev_heap_end = heap_end; 

   if ((unsigned long int)prev_heap_end % PAGE_SIZE) return (void *)-1;

   pd = get_current_page_dir();
   while (heap_end < prev_heap_end + incr) {
   	page = get_page();
   	add_page_to_page_dir(pd, heap_end, page);
	heap_end += PAGE_SIZE;
   }

   return (void *)prev_heap_end; 
}
