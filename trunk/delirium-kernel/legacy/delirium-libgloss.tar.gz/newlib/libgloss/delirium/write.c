
#include "config.h"
#include <_ansi.h>
#include <_syslist.h>
#include <errno.h>
#undef errno
extern int errno;
#include "warning.h"

extern void print(char *);

int
_DEFUN (_write, (file, ptr, len),
        int   file  _AND
        char *ptr   _AND
        int   len)
{
	int i;
	char buf[2];

	buf[1] = 0;
	for (i=0; i<len; i++) {
		buf[0] = ptr[i];
		print(buf);
	}
	
	return len;
}


